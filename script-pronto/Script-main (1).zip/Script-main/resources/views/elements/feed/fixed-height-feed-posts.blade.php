<style>
    {!! str_replace('$height', $height, file_get_contents(asset('/css/posts/height-locked-posts.css'))) !!}
</style>
